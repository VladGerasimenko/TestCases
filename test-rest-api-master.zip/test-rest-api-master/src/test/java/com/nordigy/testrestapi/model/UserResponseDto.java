package com.nordigy.testrestapi.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

// TODO: The dto can be used to map User response in Java Object. You only need to add necessary fields here.
@JsonIgnoreProperties(ignoreUnknown = true)
public class UserResponseDto {
}
